//
//  TriviaGameApp.swift
//  MLTrivia
//
//  Created by Yusuf Morsi on 4/6/22.
//

import SwiftUI

@main
struct TriviaGameApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
